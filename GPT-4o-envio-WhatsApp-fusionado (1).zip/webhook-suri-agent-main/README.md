# Webhook Checklist com IA + Alerta WhatsApp

Este projeto recebe payloads via SURI, analisa com GPT-4o e envia alertas automáticos via WhatsApp.

## Uso

1. Preencha o arquivo `.env` com suas chaves
2. Execute `npm install`
3. Rode com `node index.js`

O endpoint `/conversa` receberá mensagens da SURI.
