# 📦 Projeto GPT-4o WhatsApp - Versão Final

Servidor Express para:
- Conexão WhatsApp via WppConnect
- Análise de mensagens GPT-4o
- Alertas automáticos
- QR Code de conexão

✅ Agora 100% compatível com Railway usando Dockerfile atualizado.

## 🚀 Deploy
- Suba no GitHub
- Conecte ao Railway
- Configure `.env`
- Deploy automático!
